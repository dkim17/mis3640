"""
What is the most interesting/funny/cool thing(s) about Python that you learned from this class or from somewhere else.

You can use code or a short paragraph to illustrate it.
"""

"""
Cool thing about python is that it allows users to easily analyze and 
understand the data and text by simple typings, although it is really hard to do so.
However, after the code is designed, users can recycle the program over and over again 
by simple modification and save time in analyzing and understanding data. 
Also, python is capable of showing the result as users want. 
Therefore, users can get important and core data need very briefly. 
Through learning python, I can understand why python is a popular data science tool 
and why people are very willing to learn it in order to get a job. 
I will keep studying python even after the end of the class. 
"""