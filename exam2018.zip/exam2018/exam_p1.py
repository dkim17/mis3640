import string

def get_names():
    with open ("exam2018/roster.txt", "r") as myfile:
        name_list = [line.strip() for line in myfile]
    return name_list

def get_alphabet_value():
    alphabet_dict = {}
    for index, letter in enumerate(string.ascii_lowercase):
        alphabet_dict[letter] = index + 1
    return alphabet_dict

def get_value(name_list):
    name_score = {}
    for item in name_list:
        score = 0
        for char in item: 
            if char != ' ':
                score += alphabet_dict[char.lower()]
        name_score[item] = score
    return name_score

def highest_value(name_score):
    return max(name_score, key = name_score.get)

def get_words():
    with open ("positive-words.txt", "r") as myfile:
        pos_word_list = [line.strip() for line in myfile]
    return pos_word_list

def get_pos_words_value(pos_word_list):
    pos_word_score = {}
    for item in pos_word_list:
        score = 0
        for char in item:
            if char != ' ' and char != '-':
                score += alphabet_dict[char.lower()]
        pos_word_score[item] = score
    return pos_word_score

def get_words_with_same_value(first_name, alphabet_dict, pos_word_score):
    first_name_score = 0
    for char in first_name:
        if char != ' ':
            first_name_score += alphabet_dict[char.lower()]
    same_value_list = []
    for word, word_score in pos_word_score.items():
        if word_score == first_name_score:
            same_value_list.append(word)
    
    if len(same_value_list) == 0:
        return 'None'
    else: 
        return same_value_list

def main():
    name_list = get_names()
    alphabet_dict = get_alphabet_vlaue()
    name_score = get_value(name_list)
    highest_value_name = highest_value(name_score)
    print(highest_value_name +" is the most valuable in class")
    pos_word_list = get_words()
    pos_word_score = get_pos_words_value(pos_word_list)
    words_with_same_value = get_words_with_same_value("Dong Hyun", alphabet_dict, pos_word_list)
    print(words_with_same_value)



if __name__ == '__main__':
    main()

